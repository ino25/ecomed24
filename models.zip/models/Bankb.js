const { DataTypes } = require('sequelize');
const sequelize = require('../config').sequelize;

const Bankb = sequelize.define('Bankb', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  group: {
    type: DataTypes.STRING,
    allowNull: false
  },
  status: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  

}, {
  tableName: 'bankb',
  timestamps: false // Disable Sequelize's default timestamps
});

module.exports = Bankb;



